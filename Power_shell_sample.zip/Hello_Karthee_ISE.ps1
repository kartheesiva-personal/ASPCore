﻿Set-Variable -Name "RootUrl" -value "C:\KARTHEE\PowerShell_samples\"
Get-ChildItem -Path $RootUrl"SFTWebBackup\" * -Recurse | foreach{$_.Delete()}
Copy-Item -path $RootUrl"SFTWeb\*.*" -Destination $RootUrl"SFTWebBackup"  
Remove-Item -path $RootUrl"SFTWeb\*.*"
Remove-Item -path $RootUrl"Publish\appsettings.json"
Remove-Item -path $RootUrl"Publish\NLog.xml"
Copy-Item -path $RootUrl"Publish\*.*" -Destination $RootUrl"SFTWeb\"
Copy-Item -path $RootUrl"SFTWebBackup\appsettings.json" -Destination $RootUrl"SFTWeb\"
Copy-Item -path $RootUrl"SFTWebBackup\NLog.xml" -Destination $RootUrl"SFTWeb\"